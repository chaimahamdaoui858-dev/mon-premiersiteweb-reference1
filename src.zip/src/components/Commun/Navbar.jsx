// src/components/Commun/Navbar.jsx
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaBars, FaTimes, FaUser, FaCog, FaSignOutAlt } from 'react-icons/fa';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const location = useLocation();

  const user = {
    name: "Votre Nom",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  };

  const navigation = [
    { name: 'Accueil', path: '/' },
    { name: 'À propos', path: '/about' },
    { name: 'Expérience', path: '/experience' },
    { name: 'projects', path: '/NotFound' },
    { name: 'Contact', path: '/contact' },
  ];

  const userNavigation = [
    { name: 'Profil', path: '#profile', icon: <FaUser /> },
    { name: 'Paramètres', path: '#settings', icon: <FaCog /> },
    { name: 'Déconnexion', path: '#signout', icon: <FaSignOutAlt /> },
  ];

  return (
    <nav className="bg-gray-900 sticky top-0 z-50 shadow-lg">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">

          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-lg">
                21C
              </div>
              <span className="hidden lg:block text-white font-bold text-lg">
                21C Digital
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-2">
                {navigation.map(item => (
                  <Link
                    key={item.name}
                    to={item.path}
                    className={`rounded-lg px-4 py-2 text-sm font-medium transition ${
                      location.pathname === item.path
                        ? 'bg-gray-800 text-white shadow-md'
                        : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* Profile */}
          <div className="hidden md:flex items-center gap-4">
            <div className="relative">
              <button
                onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                className="flex items-center gap-3 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-900 transition"
              >
                <img
                  className="h-10 w-10 rounded-full ring-2 ring-gray-700 hover:ring-blue-500 transition"
                  src={user.avatar}
                  alt={user.name}
                />
                <span className="hidden lg:block text-white font-medium">{user.name}</span>
              </button>

              {isProfileDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setIsProfileDropdownOpen(false)} />
                  <div className="absolute right-0 z-20 mt-2 w-56 origin-top-right rounded-lg bg-white shadow-2xl ring-1 ring-black ring-opacity-5">
                    <div className="p-2">
                      {userNavigation.map(item => (
                        <a
                          key={item.name}
                          href={item.path}
                          className="flex items-center gap-3 rounded-md px-4 py-3 text-sm text-gray-700 hover:bg-gray-100 transition"
                          onClick={() => setIsProfileDropdownOpen(false)}
                        >
                          <span className="text-gray-500">{item.icon}</span>
                          {item.name}
                        </a>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800"
            >
              {isMobileMenuOpen ? <FaTimes className="h-6 w-6" /> : <FaBars className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-gray-800">
          <div className="px-4 pt-2 pb-3 space-y-1">
            {navigation.map(item => (
              <Link
                key={item.name}
                to={item.path}
                className={`block rounded-lg px-4 py-3 text-base font-medium ${
                  location.pathname === item.path
                    ? 'bg-gray-900 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
