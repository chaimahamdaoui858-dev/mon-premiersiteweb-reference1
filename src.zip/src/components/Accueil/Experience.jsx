import React from 'react';
import { FaBriefcase, FaCalendar, FaMapMarkerAlt, FaDownload, FaPaperclip } from 'react-icons/fa';

const Experience = () => {
  const user = {
    name: "Votre Nom",
    title: "Full-Stack Developer",
    email: "contact@21c-digital.com",
    phone: "+216 98 123 456",
    location: "Tunisie",
    experience: "5+ ans",
    availability: "Disponible immédiatement",
    bio: "Développeur passionné avec une expertise en React, WordPress, VB6 et MySQL. Spécialisé dans la création de solutions POS et d'applications web modernes. J'aime transformer des idées complexes en solutions digitales simples et efficaces.",
    
    experiences: [
      {
        id: 1,
        period: "2023 - Présent",
        role: "Développeur Full-Stack & Entrepreneur",
        company: "21C Digital",
        location: "Tunisie",
        type: "Freelance",
        description: "Création de solutions digitales personnalisées pour les entreprises tunisiennes. Développement de systèmes POS, sites WordPress et applications React modernes.",
        achievements: [
          "Développement de 15+ applications POS avec VB6 et MySQL",
          "Création de 20+ sites WordPress sur-mesure",
          "Migration de systèmes legacy vers des technologies web modernes",
          "Formation de clients sur l'utilisation des outils digitaux"
        ],
        technologies: ["React", "WordPress", "VB6", "MySQL", "Tailwind CSS"]
      },
      {
        id: 2,
        period: "2020 - 2023",
        role: "Développeur Web Senior",
        company: "Agence Digitale XYZ",
        location: "Tunis, Tunisie",
        type: "CDI",
        description: "Développement d'applications web et plugins WordPress personnalisés pour des clients nationaux et internationaux.",
        achievements: [
          "Optimisation des performances web (+40% de vitesse)",
          "Création de 30+ plugins WordPress personnalisés",
          "Gestion d'une équipe de 3 développeurs juniors",
          "Mise en place de workflows Git et CI/CD"
        ],
        technologies: ["PHP", "JavaScript", "React", "WordPress", "Node.js"]
      },
      {
        id: 3,
        period: "2018 - 2020",
        role: "Développeur Web Junior",
        company: "Startup Tech Solutions",
        location: "Sousse, Tunisie",
        type: "CDD",
        description: "Maintenance et développement de systèmes legacy. Migration progressive vers des technologies web modernes.",
        achievements: [
          "Migration de 5 applications VB6 vers le web",
          "Développement de 10+ interfaces utilisateur responsive",
          "Documentation technique complète des projets legacy",
          "Support technique client et résolution de bugs"
        ],
        technologies: ["VB6", "HTML/CSS", "JavaScript", "MySQL"]
      }
    ],

    certifications: [
      {
        name: "React Developer Certification",
        organization: "Meta",
        date: "2023",
        file: "react_certification.pdf",
        size: "1.2mb",
        url: "#"
      },
      {
        name: "WordPress Developer Expert",
        organization: "WordPress.org",
        date: "2022",
        file: "wordpress_certification.pdf",
        size: "890kb",
        url: "#"
      }
    ]
  };

  return (
    <section className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Mon Parcours Professionnel</h2>
          <p className="text-xl text-gray-600 max-w-3xl">
            {user.experience} d'expérience dans le développement web et la création de solutions digitales innovantes.
          </p>
        </div>

        {/* User Info Card */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-12">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">{user.name}</h3>
              <p className="text-lg text-blue-600 font-semibold mb-4">{user.title}</p>
              <p className="text-gray-600 leading-relaxed">{user.bio}</p>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-700">
                <FaMapMarkerAlt className="text-blue-600" />
                <span>{user.location}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <span className="text-blue-600">📧</span>
                <span>{user.email}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <span className="text-blue-600">📱</span>
                <span>{user.phone}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <FaBriefcase className="text-blue-600" />
                <span className="font-semibold text-green-600">{user.availability}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline Experience */}
        <div className="relative">
          {/* Vertical Line */}
          <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gradient-to-b from-blue-600 to-purple-600"></div>

          {/* Experience Items */}
          <div className="space-y-12">
            {user.experiences.map((exp, index) => (
              <div 
                key={exp.id}
                className={`relative grid md:grid-cols-2 gap-8 items-start ${
                  index % 2 === 0 ? '' : 'md:flex-row-reverse'
                }`}
              >
                {/* Left Side (or Right on odd items) */}
                <div className={`${index % 2 === 0 ? 'md:text-right' : 'md:col-start-2'}`}>
                  {index % 2 === 0 && (
                    <div className="hidden md:block">
                      <div className="inline-block bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition">
                        <div className="flex items-center gap-2 text-blue-600 font-semibold mb-2 justify-end">
                          <FaCalendar />
                          <span>{exp.period}</span>
                        </div>
                        <p className="text-sm text-gray-500">{exp.type}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Center Dot */}
                <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 items-center justify-center">
                  <div className="w-6 h-6 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full border-4 border-white shadow-lg z-10"></div>
                </div>

                {/* Right Side (or Left on odd items) */}
                <div className={`${index % 2 === 0 ? 'md:col-start-2' : ''}`}>
                  <div className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-2xl transition-all duration-300 hover:scale-105">
                    
                    {/* Mobile Period */}
                    <div className="md:hidden flex items-center gap-2 text-blue-600 font-semibold mb-4">
                      <FaCalendar />
                      <span>{exp.period}</span>
                      <span className="ml-auto text-sm bg-blue-100 px-3 py-1 rounded-full">{exp.type}</span>
                    </div>

                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{exp.role}</h3>
                    
                    <div className="flex items-center gap-2 text-gray-600 mb-4">
                      <FaBriefcase className="text-blue-600" />
                      <span className="font-semibold">{exp.company}</span>
                      <span className="text-gray-400">•</span>
                      <FaMapMarkerAlt className="text-gray-400" />
                      <span>{exp.location}</span>
                    </div>

                    <p className="text-gray-600 mb-6 leading-relaxed">{exp.description}</p>

                    {/* Achievements */}
                    <div className="mb-6">
                      <h4 className="text-sm font-semibold text-gray-900 mb-3 uppercase tracking-wide">Réalisations clés</h4>
                      <ul className="space-y-2">
                        {exp.achievements.map((achievement, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-gray-700">
                            <span className="text-green-500 mt-1">✓</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Technologies */}
                    <div>
                      <h4 className="text-sm font-semibold text-gray-900 mb-3 uppercase tracking-wide">Technologies</h4>
                      <div className="flex flex-wrap gap-2">
                        {exp.technologies.map((tech, idx) => (
                          <span 
                            key={idx}
                            className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium hover:bg-blue-100 transition"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Side Period (odd items) */}
                {index % 2 !== 0 && (
                  <div className="hidden md:block">
                    <div className="inline-block bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition">
                      <div className="flex items-center gap-2 text-blue-600 font-semibold mb-2">
                        <FaCalendar />
                        <span>{exp.period}</span>
                      </div>
                      <p className="text-sm text-gray-500">{exp.type}</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="mt-16 bg-white rounded-2xl shadow-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <FaPaperclip className="text-blue-600" />
            Certifications & Documents
          </h3>
          
          <ul className="divide-y divide-gray-200">
            {user.certifications.map((cert, index) => (
              <li key={index} className="py-6 hover:bg-gray-50 transition rounded-lg px-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  
                  <div className="flex items-start gap-4 flex-1">
                    <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FaPaperclip className="text-blue-600 text-xl" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="text-lg font-semibold text-gray-900 mb-1">{cert.name}</h4>
                      <p className="text-sm text-gray-600 mb-1">{cert.organization} • {cert.date}</p>
                      <div className="flex items-center gap-3 text-sm text-gray-500">
                        <span>{cert.file}</span>
                        <span>•</span>
                        <span>{cert.size}</span>
                      </div>
                    </div>
                  </div>

                  <a 
                    href={cert.url}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition shadow-md hover:shadow-lg"
                  >
                    <FaDownload />
                    Télécharger
                  </a>
                </div>
              </li>
            ))}
          </ul>
        </div>

      </div>
    </section>
  );
};

export default Experience;
