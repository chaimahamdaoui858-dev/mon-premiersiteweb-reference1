
import { Routes, Route } from "react-router-dom";

import './App.css'
import  Layout from './Pages/Layout.jsx'  
import Hero from './components/Accueil/Hero.jsx';
import About from './components/Accueil/About.jsx';
import Experience from './components/Accueil/Experience.jsx'; 
import ContactForm from './components/Formulaire/FormulaireG6.jsx';
import NotFound from "./components/NotFound";

function App() {
return (
    <Routes>
      {/* Routes publiques */}
      <Route path="/" element={<Layout />}>
        <Route index element={<Hero />} />
        <Route path="about" element={<About />} />
        <Route path="experience" element={<Experience />} />
        <Route path="contact" element={<ContactForm />} />
      </Route>

      {/* Page 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App
