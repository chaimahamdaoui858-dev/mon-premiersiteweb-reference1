// src/Pages/AdminLayout.jsx
import { Outlet, Link } from 'react-router-dom';

export default function AdminLayout() {
  return (
    <div className="min-h-screen flex">
      <div className="w-64 bg-gray-800 text-white flex flex-col p-6">
        <h2 className="text-2xl font-bold mb-6">Admin Panel</h2>
        <nav className="flex flex-col gap-3">
          <Link to="/admin" className="hover:text-indigo-300">Dashboard</Link>
          <Link to="/admin/users" className="hover:text-indigo-300">Utilisateurs</Link>
          <Link to="/admin/analytics" className="hover:text-indigo-300">Statistiques</Link>
          <Link to="/admin/settings" className="hover:text-indigo-300">Paramètres</Link>
          <Link to="/logout" className="mt-6 text-red-400 hover:text-red-600">Déconnexion</Link>
        </nav>
      </div>
      <div className="flex-grow p-8 bg-gray-100">
        <Outlet />
      </div>
    </div>
  );
}
