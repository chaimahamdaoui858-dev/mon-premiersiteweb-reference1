// src/Pages/admin/AdminAnalytics.jsx
import React from 'react';

export default function AdminAnalytics() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Statistiques</h1>
      <p className="text-gray-700">Graphiques et statistiques à venir...</p>
    </div>
  );
}
