// src/Pages/admin/Settings.jsx
import React from 'react';

export default function AdminSettings() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Paramètres</h1>
      <p className="text-gray-700">Paramètres et préférences de l'administration.</p>
    </div>
  );
}
